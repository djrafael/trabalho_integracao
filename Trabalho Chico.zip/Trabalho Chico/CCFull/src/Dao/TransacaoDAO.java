package Dao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Entity.Transacao;

public class TransacaoDAO{
    ConectaBD conexao = new ConectaBD();


    public void realizarTransacao(String nome_estabelecimento, Transacao transacao){
    String sql = "INSERT INTO transacao (nome_estabelecimento, valor_compra, id_cartao) VALUES (?, ?, ?)";
        try {
        PreparedStatement pstTransacao = conexao.getConexao().prepareStatement(sql);
        pstTransacao.setString(1, nome_estabelecimento);
        pstTransacao.setDouble(2,transacao.getValor_compra());
        pstTransacao.setInt(3, transacao.getId_cartao());
        pstTransacao.executeUpdate();

        System.out.println("Transação inserida com sucesso!");
    } catch (SQLException e) {
        System.out.println("Erro ao inserir transação: " + e.getMessage());
    }
    }

    public String[] listaCartao(String documentoTitular) {
    String[] listacartao = null;
    String sql = "SELECT c.id_cartao, c.numero_cartao " +
                 "FROM Cartao c " +
                 "INNER JOIN Pessoa p ON c.cpf_pessoa = p.cpf " +
                 "WHERE p.cpf = ?";

    try {
        PreparedStatement pstTransacao = conexao.getConexao().prepareStatement(sql);
        pstTransacao.setString(1, documentoTitular);

        ResultSet rs = pstTransacao.executeQuery();

        // Get the number of rows returned by the query
        int rowCount = getRowCount(rs);

        if (rowCount > 0) {
            listacartao = new String[rowCount];
            int index = 0;
            while (rs.next()) {
                String id_cartao = rs.getString("id_cartao");
                String numero_cartao = rs.getString("numero_cartao");
                listacartao[index] = id_cartao + " - " + numero_cartao;
                index++;
            }
        }

        rs.close();
        System.out.println("Consulta de cartões concluída com sucesso!");
    } catch (SQLException e) {
        System.out.println("Erro ao consultar cartões: " + e.getMessage());
    }

    return listacartao;
}
   public double verificaSaldo(int id_cartao) {
    String sql = "SELECT saldo FROM cartao WHERE id_cartao = ?";
    double saldo = 0;

    try {
        PreparedStatement pstTransacao = conexao.getConexao().prepareStatement(sql);
        pstTransacao.setInt(1, id_cartao);
        ResultSet rs = pstTransacao.executeQuery();

        if (rs.next()) {
            saldo = rs.getDouble("saldo");
        }

        rs.close();
    } catch (SQLException e) {
        System.out.println("Erro ao consultar saldo: " + e.getMessage());
    }

    return saldo;
    }





private int getRowCount(ResultSet resultSet) throws SQLException {
    int rowCount = 0;
    if (resultSet.last()) {
        rowCount = resultSet.getRow();
        resultSet.beforeFirst();
    }
    return rowCount;
}

public void pagarFatura(int idcartao, double valorPagamento) {
}




}

