package Dao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Entity.Cartao;

    public class CartaoDAO {
        ConectaBD conexao = new ConectaBD();
    
        public void inserirCartao(Cartao cartao, String documentoTitular) {
            String sqlPessoa = "INSERT INTO pessoa (cpf, nome) VALUES (?, ?)";
            String sqlCartao = "INSERT INTO cartao (numero_cartao, validade, limite_cartao, cpf_pessoa, is_principal) VALUES (?, ?, ?, ?, true)";

            try {
                // Inserir dados do titular na tabela Pessoa
                PreparedStatement pstPessoa = conexao.getConexao().prepareStatement(sqlPessoa);
                pstPessoa.setString(1, documentoTitular);
                pstPessoa.setString(2, cartao.getNomeTitular());
                pstPessoa.executeUpdate();

                // Inserir dados do cartão na tabela Cartao
                PreparedStatement pstCartao = conexao.getConexao().prepareStatement(sqlCartao);
                pstCartao.setString(1, cartao.getNumeroCartao());
                pstCartao.setString(2, cartao.getDataValidade().toString());
                pstCartao.setDouble(3, cartao.getLimiteCredito());
                pstCartao.setString(4, documentoTitular);
                pstCartao.executeUpdate();

                System.out.println("Cartão adicional inserido com sucesso!");
                } catch (SQLException e) {
                System.out.println("Erro ao inserir cartão adicional: " + e.getMessage());
                }
            }



        public String verificarCPFPresente(String cpf) {
            String cpfEncontrado = null;
            String sql = "SELECT cpf FROM pessoa WHERE cpf = ?";

            try {
                PreparedStatement pst = conexao.getConexao().prepareStatement(sql);
                pst.setString(1, cpf);
                ResultSet rs = pst.executeQuery();

                if (rs.next()) {
                    cpfEncontrado = rs.getString("cpf");
                }

                rs.close();
            } catch (SQLException e) {
                System.out.println("Erro ao verificar CPF no banco de dados: " + e.getMessage());
            }

            return cpfEncontrado;
        }



        public double consultarLimiteCartao(String cpf) {
            double Limiteverificado = 0.0;
            String sql = "SELECT c.limite_cartao FROM Cartao c WHERE c.is_principal = TRUE AND c.cpf_pessoa = ?";

            try {
                PreparedStatement pst = conexao.getConexao().prepareStatement(sql);
                pst.setString(1, cpf);
                ResultSet rs = pst.executeQuery();

                if (rs.next()) {
                    Limiteverificado = rs.getDouble("limite_cartao");
                }

                rs.close();
            } catch (SQLException e) {
                System.out.println("Erro ao consultar limite do cartão: " + e.getMessage());
            }

            return Limiteverificado;
        }



        public void inserirCartaoadicional(Cartao cartao, String documentoTitular) {
            ConectaBD conexao = new ConectaBD();
            String sqlCartao = "INSERT INTO cartao (numero_cartao, validade, limite_cartao, cpf_pessoa, is_principal) VALUES (?, ?, ?, ?, false)";

            try {
                // Inserir dados do cartão na tabela Cartao
                PreparedStatement pstCartao = conexao.getConexao().prepareStatement(sqlCartao);
                pstCartao.setString(1, cartao.getNumeroCartao());
                pstCartao.setString(2, cartao.getDataValidade().toString());
                pstCartao.setDouble(3, cartao.getLimiteCredito());
                pstCartao.setString(4, documentoTitular);
                pstCartao.executeUpdate();

                System.out.println("Cartão adicional inserido com sucesso!");
                } catch (SQLException e) {
                System.out.println("Erro ao inserir cartão adicional: " + e.getMessage());
                }
        }
        
        
        
        
        
        
        
        
        
        
        public void pagarFatura(int id_cartao, double valor) {
        ConectaBD conexao = new ConectaBD();
        String sqlCartao = "SELECT id_cartao, numero_cartao, limite_cartao, saldo FROM cartao WHERE id_cartao = ?";

        try {
        PreparedStatement pstCartao = conexao.getConexao().prepareStatement(sqlCartao);
        pstCartao.setInt(1, id_cartao);

        ResultSet rsCartao = pstCartao.executeQuery();

        if (rsCartao.next()) {
            Cartao cartao = new Cartao(id_cartao);
            cartao.setId_cartao(rsCartao.getInt("id_cartao"));
            cartao.setNumero_cartao(rsCartao.getString("numero_cartao"));
            cartao.setLimite_cartao(rsCartao.getDouble("limite_cartao"));
            cartao.setSaldo(rsCartao.getDouble("saldo"));

            double novoSaldo = cartao.getSaldo() - valor;
            if (novoSaldo >= 0) {
                String sqlAtualizarSaldo = "UPDATE cartao SET saldo = ? WHERE id_cartao = ?";
                PreparedStatement pstAtualizarSaldo = conexao.getConexao().prepareStatement(sqlAtualizarSaldo);
                pstAtualizarSaldo.setDouble(1, novoSaldo);
                pstAtualizarSaldo.setInt(2, cartao.getId_cartao());
                pstAtualizarSaldo.executeUpdate();

                System.out.println("Fatura paga com sucesso!");
            } else {
                System.out.println("Saldo insuficiente para pagar a fatura.");
            }
        } else {
            System.out.println("Cartão não encontrado.");
        }

        rsCartao.close();
    } catch (SQLException e) {
        System.out.println("Erro ao consultar cartão: " + e.getMessage());
    }
    }
}


