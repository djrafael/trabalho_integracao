package Entity;

public class Transacao {
    private String nome_estabelecimento;
    private double valor_compra;
    private int id_cartao;

    public Transacao(int id_cartao){
        this.id_cartao = id_cartao;

    }


    public Transacao(String nome_estabelecimento, double valor_compra, int id_cartao) {
        this.nome_estabelecimento = nome_estabelecimento;
        this.valor_compra = valor_compra;
        this.id_cartao = id_cartao;
    }
    public String getNome_estabelecimento() {
        return nome_estabelecimento;
    }
    public void setNome_estabelecimento(String nome_estabelecimento) {
        this.nome_estabelecimento = nome_estabelecimento;
    }
    public double getValor_compra() {
        return valor_compra;
    }
    public void setValor_compra(double valor_compra) {
        this.valor_compra = valor_compra;
    }
    public int getId_cartao() {
        return id_cartao;
    }
    public void setId_cartao(int id_cartao) {
        this.id_cartao = id_cartao;
    }
    
}
