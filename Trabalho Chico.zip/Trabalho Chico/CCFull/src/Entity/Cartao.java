package Entity;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class Cartao {
    private int id_cartao;
    

    private String nomeTitular;
    private String documentoTitular;
    private String numeroCartao;
    private LocalDate data;
    private double limiteCredito;
    private double saldo;

    public Cartao(int id_cartao) {
        this.id_cartao = id_cartao;
    }
    public Cartao(String nomeTitular, String documentoTitular, double limiteCredito) {
        
        this.nomeTitular = nomeTitular;
        this.documentoTitular = documentoTitular;
        this.numeroCartao = gerarNumeroCartao();
        this.data = gerarDataValidade();
        this.limiteCredito = limiteCredito;
        this.saldo = limiteCredito;
    }

    public String getNomeTitular() {
        return nomeTitular;
    }

    public String getDocumentoTitular() {
        return documentoTitular;
    }

    public String getNumeroCartao() {
        return numeroCartao;
    }

    public LocalDate getDataValidade() {
        return data;
    }

    public double getLimiteCredito() {
        return limiteCredito;
    }
    public double getSaldo() {
        return saldo;
    }
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    public int getId_cartao() {
        return id_cartao;
    }

    public void setId_cartao(int id_cartao) {
        this.id_cartao = id_cartao;
    }

    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String dataValidadeStr = data.format(formatter);

        return "Cartao{" +
                "nomeTitular='" + nomeTitular + '\'' +
                ", documentoTitular='" + documentoTitular + '\'' +
                ", numeroCartao='" + numeroCartao + '\'' +
                ", dataValidade='" + dataValidadeStr + '\'' +
                ", limiteCredito=" + limiteCredito +
                '}';
    }

    private String gerarNumeroCartao() {
        Random random = new Random();
        StringBuilder numeroCartao = new StringBuilder();
        for (int i = 0; i < 16; i++) {
            int digito = random.nextInt(10);
            numeroCartao.append(digito);
        }
        return numeroCartao.toString();
    }

    private LocalDate gerarDataValidade() {
        LocalDate dataAtual = LocalDate.now();
        return dataAtual.plusYears(5);
    }
    public void setNumero_cartao(String string) {
    }
    public void setLimite_cartao(double double1) {
    }
}