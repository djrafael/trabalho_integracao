package Main;

import java.util.Scanner;
import Dao.CartaoDAO;
import Dao.TransacaoDAO;
import Entity.Cartao;
import Entity.Transacao;


public class App {
    public static void main(String[] args) {
        int op;
        do {
            op = menu();
            switch (op) {
                case 1:
                    emitirCartao();
                    break;
                case 2:
                    emitirCartaoAdicional();
                    break;
                case 3:
                    realizarTransacao();
                    break;
                case 4:
                    consultarSaldoDisponivel();
                    break;
                case 5:
                    pagarFatura();
                    break;
                case 6:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida. Por favor, tente novamente.");
            }
        } while (op != 5);
    }


    public static int menu() {
        Scanner teclado = new Scanner(System.in);
        System.out.println("MENU");
        System.out.println("1- Emitir Cartão");
        System.out.println("2- Emitir Cartão Adicional");
        System.out.println("3- Realizar Compra");
        System.out.println("4- Consultar Saldo Disponível");
        System.out.println("5- Pagar Fatura");
        System.out.println("6- Sair\n");
        System.out.print("Escolha uma opção: ");
        return teclado.nextInt();
    }

    public static void emitirCartao() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Emitir Cartão");
        System.out.print("Nome do titular: ");
        String nomeTitular = scanner.nextLine();
        System.out.print("Documento do titular: ");
        String documentoTitular = scanner.nextLine();
        System.out.print("Limite de crédito: ");
        double limiteCredito = scanner.nextDouble();

        Cartao cartao = new Cartao(nomeTitular, documentoTitular, limiteCredito);
        CartaoDAO cartaoDAO = new CartaoDAO();
        cartaoDAO.inserirCartao(cartao, documentoTitular);
        System.out.println("Cartão emitido com sucesso: " + cartao);
    }

    public static void emitirCartaoAdicional() {
        Scanner scanner = new Scanner(System.in);
        CartaoDAO cartaoDAO = new CartaoDAO();
        String documentoTitular;

        System.out.println("Emitir Cartão Adicional");

        do {
            System.out.print("CPF do titular do cartão adicional: ");
            documentoTitular = scanner.nextLine();

            if (cartaoDAO.verificarCPFPresente(documentoTitular) == null) {
                System.out.println("CPF não encontrado. Por favor, digite um CPF válido.");
            }
            else{
                    System.out.println("Digite limite do cartão adicional: ");
                    double limiteCredito = scanner.nextDouble();

                    double limiteverificado = cartaoDAO.consultarLimiteCartao(documentoTitular);

                    if(limiteverificado <= limiteCredito){
                        System.out.println("O limite do cartão adicional não pode ser maior que o cartão principal, tente outro valor");
                    }
                    else{
                        Cartao cartao = new Cartao(documentoTitular, documentoTitular, limiteCredito);
                        cartaoDAO.inserirCartaoadicional(cartao, documentoTitular);
                        System.out.println("Cartão emitido com sucesso: " + cartao);
                        
                    }
                }
            } while (cartaoDAO.verificarCPFPresente(documentoTitular) == null);
        } 

    

    public static void realizarTransacao() {
    TransacaoDAO transacaoDAO = new TransacaoDAO();
    Scanner scanner = new Scanner(System.in);
    System.out.println("Realizar transação");
    System.out.println("Digite o CPF do Titular do cartão:");
    String documentoTitular = scanner.nextLine();
    System.out.print("Nome do estabelecimento: ");
    String nome_estabelecimento = scanner.nextLine();
    System.out.print("Digite o valor da compra: ");
    double valor_compra = scanner.nextDouble();
    System.out.println("Selecione o Cartao");
    System.out.println("Qual o tipo da operação");

    String[] listaCartao = transacaoDAO.listaCartao(documentoTitular);
    int escolha = 0;
    if (listaCartao != null) {
        for (int i = 0; i < listaCartao.length; i++) {
            String[] cartaoInfo = listaCartao[i].split("-");
            String idcartao = cartaoInfo[0].trim();
            String numerocartao = cartaoInfo[1].trim();
            System.out.println(idcartao + " - " + numerocartao);
        }
        System.out.print("Digite o número do cartão desejado: ");
        escolha = scanner.nextInt();
        if (escolha >= 1 && escolha <= listaCartao.length) {
            String[] cartaoInfo = listaCartao[escolha - 1].split("-");
            int idcartao = Integer.parseInt(cartaoInfo[0].trim());
            Transacao transacao = new Transacao(nome_estabelecimento, valor_compra, idcartao);
            transacaoDAO.realizarTransacao(nome_estabelecimento, transacao);
        } else {
            System.out.println("Opção inválida.");
        }
    } else {
        System.out.println("Nenhum cartão encontrado para o CPF informado.");
    }
    }





    public static void consultarSaldoDisponivel() {
    TransacaoDAO transacaoDAO = new TransacaoDAO();
    Scanner scanner = new Scanner(System.in);
    System.out.println("Consultar Saldo Disponível");
    System.out.println("Digite o CPF do titular do cartão:");
    String documentoTitular = scanner.nextLine();
    String[] listaCartao = transacaoDAO.listaCartao(documentoTitular);
    int escolha = 0;
    if (listaCartao != null) {
        for (int i = 0; i < listaCartao.length; i++) {
            String[] cartaoInfo = listaCartao[i].split("-");
            String idcartao = cartaoInfo[0].trim();
            String numerocartao = cartaoInfo[1].trim();
            System.out.println(idcartao + " - " + numerocartao);
        }
        System.out.print("Digite o número do cartão desejado: ");
        escolha = scanner.nextInt();
        double saldo = transacaoDAO.verificaSaldo(escolha);
        System.out.println("Fatura atual: " + saldo);

    } else {
        System.out.println("Nenhum cartão encontrado para o CPF informado.");
    }
    }
        


    private static void pagarFatura() {
    TransacaoDAO transacaoDAO = new TransacaoDAO();
    CartaoDAO cartaoDAO = new CartaoDAO();
    Scanner scanner = new Scanner(System.in);
    System.out.println("Pagar Fatura");
    System.out.println("Digite o CPF do titular do cartão:");
    String documentoTitular = scanner.nextLine();
    String[] listaCartao = transacaoDAO.listaCartao(documentoTitular);
    int escolha = 0;
    if (listaCartao != null) {
        for (int i = 0; i < listaCartao.length; i++) {
            String[] cartaoInfo = listaCartao[i].split("-");
            String idcartao = cartaoInfo[0].trim();
            String numerocartao = cartaoInfo[1].trim();
            System.out.println(idcartao + " - " + numerocartao);
        }
        System.out.print("Digite o número do cartão desejado: ");
        escolha = scanner.nextInt();
        if (escolha >= 1 && escolha <= listaCartao.length) {
            System.out.print("Digite o valor a ser pago: ");
            double valorPagamento = scanner.nextDouble();
            String[] cartaoInfo = listaCartao[escolha - 1].split("-");
            int idcartao = Integer.parseInt(cartaoInfo[0].trim());

            cartaoDAO.pagarFatura(idcartao, valorPagamento);
        } else {
            System.out.println("Opção inválida.");
        }
    } else {
        System.out.println("Nenhum cartão encontrado para o CPF informado.");
    }
}




    


}

    
